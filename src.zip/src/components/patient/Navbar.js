// src/components/patient/Navbar.js
import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Search, Bell, Sun, Moon, User, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import Fuse from "fuse.js";
import { useTheme } from "../../context/ThemeContext";

const logoUrl = "https://i.ibb.co/YgFJMvx/patient-connect-logo.png";

const PatientNavbar = ({ isSidebarOpen, toggleSidebar, allPages = [] }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { darkMode, toggleDarkMode, accentColor } = useTheme();

  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const searchRef = useRef(null);

  // ✅ Global search index — includes pages, doctors, patients, and proper nouns
  const fullSearchIndex = [
    ...allPages,

    // === Patient Pages ===
    {
      title: "My Dashboard",
      path: "/patient/dashboard",
      description: "View your health overview, reminders, and updates",
      keywords: ["overview", "summary", "insights"],
    },
    {
      title: "Appointments",
      path: "/patient/appointments",
      description: "View and manage your upcoming and past appointments",
      keywords: ["doctor", "appointment", "schedule", "visit"],
    },
    {
      title: "Messages",
      path: "/patient/messages",
      description: "Chat with your doctor securely in real time",
      keywords: ["messages", "chat", "communication", "doctor"],
    },
    {
      title: "Prescriptions",
      path: "/patient/prescriptions",
      description: "View and download your prescriptions",
      keywords: ["prescription", "medication", "pharmacy"],
    },
    {
      title: "Lab Reports",
      path: "/patient/reports",
      description: "Access, download, and share your lab test reports",
      keywords: ["lab", "report", "blood test", "results"],
    },
    {
      title: "Settings",
      path: "/patient/settings",
      description: "Manage your profile, preferences, and theme",
      keywords: ["settings", "preferences", "account"],
    },

    // === Doctors ===
    {
      title: "Dr. Meera",
      path: "/doctor/meera",
      description: "Cardiologist — Expert in heart and vascular health",
      keywords: [
        "dr meera",
        "meera",
        "cardiology",
        "heart specialist",
        "cardiologist",
        "consultation",
      ],
    },
    {
      title: "Dr. Rajesh",
      path: "/doctor/rajesh",
      description: "Dermatologist — Specialist in skin, hair, and nails",
      keywords: ["dr rajesh", "dermatologist", "skin doctor", "eczema", "acne"],
    },
    {
      title: "Dr. Arjun Patel",
      path: "/doctor/arjun",
      description: "Orthopedic Surgeon — Bone and joint specialist",
      keywords: [
        "dr arjun",
        "orthopedic",
        "bone",
        "joint",
        "fracture",
        "musculoskeletal",
      ],
    },

    // === Patients ===
    {
      title: "John Doe",
      path: "/patient/johndoe",
      description: "General patient record",
      keywords: ["john doe", "patient john", "profile", "records"],
    },
    {
      title: "Aisha Khan",
      path: "/patient/aishakhan",
      description: "Active treatment and health overview",
      keywords: ["aisha khan", "patient aisha", "female", "appointment"],
    },
    {
      title: "Ravi Patel",
      path: "/patient/ravipatel",
      description: "Post-surgery recovery and follow-up visits",
      keywords: ["ravi patel", "male patient", "recovery", "follow-up"],
    },

    // === Proper Nouns / Keywords ===
    {
      title: "Cardiology",
      path: "/search/cardiology",
      description: "Heart and vascular health related resources",
      keywords: ["cardiology", "heart", "doctor", "dr meera"],
    },
    {
      title: "Dermatology",
      path: "/search/dermatology",
      description: "Skin, hair, and nail treatments",
      keywords: ["skin", "dermatology", "dr rajesh", "eczema", "acne"],
    },
    {
      title: "Orthopedics",
      path: "/search/orthopedics",
      description: "Bone and joint health management",
      keywords: ["orthopedic", "bone", "joint", "surgery", "dr arjun"],
    },
  ];

  // ✅ Fuse.js setup
  const fuse = new Fuse(fullSearchIndex, {
    keys: ["title", "keywords", "description"],
    includeScore: true,
    threshold: 0.3,
    ignoreLocation: true,
  });

  // ✅ Hide dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setShowResults(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ✅ Run search
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setShowResults(false);
      return;
    }
    const searchResults = fuse.search(query);
    setResults(searchResults.map((r) => r.item));
    setShowResults(true);
  }, [query]);

  const handleResultClick = (path) => {
    navigate(path);
    setQuery("");
    setShowResults(false);
  };

  return (
    <nav
      className={`fixed top-0 z-50 w-full backdrop-blur-md transition-all duration-500 shadow-sm border-b ${
        darkMode
          ? "bg-gray-900/70 border-gray-800 text-white"
          : "bg-white/80 border-gray-200 text-gray-900"
      }`}
      style={{ "--accent": accentColor }}
    >
      <div className="flex items-center justify-between px-3 sm:px-6 py-3">
        {/* === LEFT SECTION === */}
        <div className="flex items-center gap-3">
          <motion.button
            onClick={toggleSidebar}
            whileTap={{ scale: 0.9 }}
            animate={{ rotate: isSidebarOpen ? 90 : 0 }}
            transition={{ duration: 0.3 }}
            className="relative p-2 rounded-full transition-all duration-300"
            style={{
              backgroundColor: darkMode ? "#1f2937" : "#f3f4f6",
              color: accentColor,
              boxShadow: isSidebarOpen
                ? `0 0 10px 2px ${accentColor}80`
                : `0 0 4px 1px ${accentColor}40`,
            }}
            title={isSidebarOpen ? "Close Sidebar" : "Open Sidebar"}
          >
            <AnimatePresence mode="wait" initial={false}>
              {isSidebarOpen ? (
                <motion.span
                  key="close"
                  initial={{ opacity: 0, rotate: -90 }}
                  animate={{ opacity: 1, rotate: 0 }}
                  exit={{ opacity: 0, rotate: 90 }}
                  transition={{ duration: 0.3 }}
                >
                  <X size={20} />
                </motion.span>
              ) : (
                <motion.span
                  key="menu"
                  initial={{ opacity: 0, rotate: 90 }}
                  animate={{ opacity: 1, rotate: 0 }}
                  exit={{ opacity: 0, rotate: -90 }}
                  transition={{ duration: 0.3 }}
                >
                  <Menu size={20} />
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>

          <div
            onClick={() => navigate("/patient/dashboard")}
            className="flex items-center gap-2 cursor-pointer select-none"
          >
            <img
              src={logoUrl}
              alt="Patient-Connect"
              className="w-8 h-8 rounded-full drop-shadow-md"
              style={{
                border: `2px solid ${accentColor}`,
                boxShadow: `0 0 8px ${accentColor}60`,
              }}
            />
            <span
              className="font-semibold text-lg hidden sm:block transition-colors"
              style={{
                color: accentColor,
                textShadow: `0 0 6px ${accentColor}40`,
              }}
            >
              Patient-Connect
            </span>
          </div>
        </div>

        {/* === SEARCH BAR === */}
        <div ref={searchRef} className="relative flex-1 max-w-xl mx-4 hidden sm:flex">
          <div
            className="flex items-center rounded-full border w-full transition-colors duration-300"
            style={{
              backgroundColor: darkMode ? "#1f2937" : "#f3f4f6",
              borderColor: accentColor,
              boxShadow: `0 0 8px ${accentColor}30`,
            }}
          >
            <Search className="ml-3" size={18} style={{ color: accentColor }} />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search appointments, doctors, reports, messages..."
              className={`w-full px-3 py-2 bg-transparent outline-none rounded-full text-sm ${
                darkMode ? "text-white placeholder-gray-400" : "text-gray-900"
              }`}
            />
          </div>

          {/* ✅ Slightly moved dropdown */}
          <AnimatePresence>
            {showResults && results.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 3 }}
                exit={{ opacity: 0, y: -5 }}
                transition={{ duration: 0.2 }}
                className={`absolute mt-10 w-full rounded-lg shadow-xl overflow-hidden z-50 max-h-72 overflow-y-auto ${
                  darkMode ? "bg-gray-800" : "bg-white"
                }`}
              >
                {results.map((res, i) => (
                  <div
                    key={i}
                    onClick={() => handleResultClick(res.path)}
                    className="px-4 py-2 cursor-pointer transition-all text-sm"
                    style={{ color: accentColor }}
                    onMouseEnter={(e) =>
                      (e.currentTarget.style.backgroundColor = accentColor + "25")
                    }
                    onMouseLeave={(e) =>
                      (e.currentTarget.style.backgroundColor = "transparent")
                    }
                  >
                    <p className="font-medium">{res.title}</p>
                    {res.description && (
                      <p
                        className={`text-xs mt-0.5 ${
                          darkMode ? "text-gray-400" : "text-gray-600"
                        }`}
                      >
                        {res.description}
                      </p>
                    )}
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* === RIGHT SECTION === */}
        <div className="flex items-center gap-3">
          <button className="p-2 rounded-full transition" style={{ color: accentColor }}>
            <Bell size={20} />
          </button>
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-full transition"
            style={{
              color: accentColor,
              backgroundColor: darkMode ? "#1f2937" : "#f3f4f6",
            }}
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button
            onClick={() => navigate("/patient/settings")}
            className="p-2 rounded-full transition"
            style={{ color: accentColor }}
          >
            <User size={20} />
          </button>
        </div>
      </div>
    </nav>
  );
};

export default PatientNavbar;
