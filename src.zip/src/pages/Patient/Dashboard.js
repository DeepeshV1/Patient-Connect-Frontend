// src/pages/Patient/PatientDashboard.js
import React, { useState } from "react";
import {
  FiThermometer,
  FiTrendingUp,
  FiActivity,
  FiCalendar,
  FiBell,
  FiMessageCircle,
  FiBookOpen,
} from "react-icons/fi";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { useTheme } from "../../context/ThemeContext";
import { usePatientData } from "../../hooks/usePatientData";
import { FaHeartbeat } from "react-icons/fa";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const PatientDashboard = () => {
  const navigate = useNavigate();
  const { darkMode, accentColor = "#14b8a6" } = useTheme();

  const patient = usePatientData(1);
  const vitals = patient?.vitals || {
    heartRate: 80.8,
    oxygen: 98.8,
    temperature: 98.7,
    bloodPressure: "119/80",
  };

  const appointments = patient?.appointments || [
    { id: 1, date: "Oct 30, 2025", time: "10:30 AM", doctor: "Dr. Priya Natarajan" },
    { id: 2, date: "Nov 3, 2025", time: "03:00 PM", doctor: "Dr. Karthik Iyer" },
  ];

  const notifications = patient?.notifications || [
    { id: 1, message: "Time for your evening medication 💊", time: "5 mins ago" },
    { id: 2, message: "Appointment confirmed with Dr. Priya tomorrow", time: "1 hr ago" },
  ];

  const [compareMode, setCompareMode] = useState(false);
  const [showAppreciation, setShowAppreciation] = useState(false);

  const textColor = darkMode ? "text-gray-100" : "text-gray-800";
  const subTextColor = darkMode ? "text-gray-400" : "text-gray-600";

  const handleCompareClick = () => {
    setCompareMode((prev) => !prev);
    setShowAppreciation(true);
  };

  const bpDataCurrent = [
    { day: "Mon", sys: 118, dia: 78 },
    { day: "Tue", sys: 120, dia: 79 },
    { day: "Wed", sys: 119, dia: 80 },
    { day: "Thu", sys: 121, dia: 82 },
    { day: "Fri", sys: 118, dia: 77 },
    { day: "Sat", sys: 119, dia: 80 },
    { day: "Sun", sys: 120, dia: 81 },
  ];

  const bpDataPrevious = [
    { day: "Mon", sys: 125, dia: 85 },
    { day: "Tue", sys: 126, dia: 84 },
    { day: "Wed", sys: 123, dia: 83 },
    { day: "Thu", sys: 124, dia: 86 },
    { day: "Fri", sys: 122, dia: 82 },
    { day: "Sat", sys: 123, dia: 84 },
    { day: "Sun", sys: 124, dia: 85 },
  ];

  const displayedBPData = compareMode ? bpDataPrevious : bpDataCurrent;

  return (
    <div className="p-6 space-y-8">
      {/* 🌿 Banner */}
      <div
        className="text-white rounded-2xl p-6 shadow-md"
        style={{
          background: `linear-gradient(to right, ${accentColor}, #0ea5e9)`,
        }}
      >
        <h2 className="text-2xl font-bold">
          Good morning, {patient?.patientName || "Aravind Kumar"} 👋
        </h2>
        <p className="text-sm opacity-90 mt-1">
          Here’s your health overview for today. You have {appointments.length}{" "}
          upcoming appointment{appointments.length !== 1 ? "s" : ""} this week.
        </p>
        <div className="mt-4 flex flex-wrap gap-3">
          <button
            onClick={() => navigate("/patient/appointments")}
            className="font-semibold px-4 py-2 rounded-xl shadow transition"
            style={{
              backgroundColor: accentColor,
              color: "#fff",
            }}
          >
            <FiCalendar className="inline mr-2" /> Schedule Appointment
          </button>
          <button
            onClick={() => navigate("/patient/lab-reports")}
            className="bg-white text-[var(--accent-color)] font-semibold px-4 py-2 rounded-xl shadow hover:bg-gray-100 transition"
            style={{
              color: accentColor,
            }}
          >
            <FiBookOpen className="inline mr-2" /> View Reports
          </button>
          <button
            onClick={() => navigate("/patient/messages")}
            className="bg-white/20 text-white font-semibold px-4 py-2 rounded-xl shadow hover:bg-white/30 transition"
          >
            <FiMessageCircle className="inline mr-2" /> Message Doctor
          </button>
        </div>
      </div>

      {/* 🩺 Health Monitor */}
      <section>
        <div className="flex flex-wrap items-center justify-between mb-4 gap-3">
          <h3 className={`text-xl font-semibold ${textColor}`}>
            Health Stats
          </h3>
          <button
            onClick={handleCompareClick}
            className="px-3 py-1.5 text-sm font-semibold text-white rounded-lg shadow transition"
            style={{ backgroundColor: accentColor }}
          >
            {compareMode ? "Show Current" : "Compare with Last Week"}
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[
            {
              label: "Heart Rate",
              value: "80.8",
              unit: "bpm",
              icon: (
                <FaHeartbeat className="text-red-500 text-lg animate-pulse" />
              ),
            },
            {
              label: "SpO₂",
              value: "98.8",
              unit: "%",
              icon: <FiActivity className="text-blue-500 text-lg" />,
            },
            {
              label: "Temperature",
              value: "98.7",
              unit: "°F",
              icon: <FiThermometer className="text-yellow-500 text-lg" />,
            },
            {
              label: "Blood Pressure",
              value: "119/80",
              unit: "",
              icon: <FiTrendingUp className="text-purple-500 text-lg" />,
            },
          ].map((item, i) => (
            <motion.div
              key={i}
              whileHover={{ scale: 1.05 }}
              className="from-white to-teal-50 dark:from-gray-800 dark:to-gray-700 rounded-2xl shadow-md p-4 text-center border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
            >
              <div className="flex justify-center items-center mb-1">
                {item.icon}
              </div>
              <p className={`text-sm ${subTextColor}`}>{item.label}</p>
              <p className="text-2xl font-bold text-green-500">
                {item.value} {item.unit}
              </p>
              <p className="text-xs text-green-500 mt-1">Stable</p>
            </motion.div>
          ))}
        </div>

        {showAppreciation && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 p-4 rounded-lg text-center shadow-md bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200"
          >
            💚 Great progress! Your blood pressure is improving. Keep your
            hydration levels steady and take short walks regularly.
          </motion.div>
        )}
      </section>

      {/* 📊 Graph + Tips */}
      <section className="mt-8">
        <div className="flex flex-col lg:flex-row gap-6 items-stretch">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-4 w-full lg:w-1/2">
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={displayedBPData}>
                <XAxis dataKey="day" stroke="#9CA3AF" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="sys" stroke={accentColor} strokeWidth={3} name="Systolic" />
                <Line type="monotone" dataKey="dia" stroke="#3b82f6" strokeWidth={3} name="Diastolic" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-5 w-full lg:w-1/2 flex flex-col justify-center">
            <h4 className="text-lg font-semibold text-green-700 dark:text-green-300 mb-2">
              🌿 Health Insights & Tips
            </h4>
            <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
              • Systolic and diastolic readings are improving compared to last week.
            </p>
            <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
              • Stay hydrated and get 7–8 hours of sleep to maintain heart balance.
            </p>
            <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
              • Continue mild exercise and balanced diet — you’re doing great!
            </p>
            <div className="mt-3 text-green-600 dark:text-green-300 font-medium">
              💬 “Your body appreciates your consistency.”
            </div>
          </div>
        </div>
      </section>

      {/* 📅 Appointments & 🔔 Notifications */}
      <section className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-5">
          <h4 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <FiCalendar style={{ color: accentColor }} /> Upcoming Appointments
          </h4>
          {appointments.map((appt) => (
            <div
              key={appt.id}
              className="p-3 mb-2 rounded-lg bg-teal-50 dark:bg-gray-700 flex justify-between items-center"
            >
              <div>
                <p className="font-medium text-gray-800 dark:text-gray-100">{appt.doctor}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {appt.date} • {appt.time}
                </p>
              </div>
            <button
  onClick={() => navigate("/patient/appointments")}
  className="text-sm font-medium hover: glow"
  style={{ color: accentColor }}
>
  View
</button>

            </div>
          ))}
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-5">
          <h4 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <FiBell className="text-yellow-500" /> Recent Notifications
          </h4>
          {notifications.map((note) => (
            <div
              key={note.id}
              className="p-3 mb-2 rounded-lg bg-yellow-50 dark:bg-gray-700"
            >
              <p className="text-gray-800 dark:text-gray-100">{note.message}</p>
              <p className="text-xs text-gray-500 mt-1">{note.time}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default PatientDashboard;
