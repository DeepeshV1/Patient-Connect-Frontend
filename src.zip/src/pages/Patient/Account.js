// src/pages/Patient/Account.js
import React from "react";
import { User } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";

const Account = () => {
  const { accentColor } = useTheme();
  const patient = {
    name: "Deepesh Kumar",
    email: "deepesh@example.com",
    phone: "+91 98765 43210",
    dob: "1995-03-21",
  };

  return (
    <div className="space-y-6">
      <header>
        <h1
          className="text-2xl font-semibold flex items-center gap-2"
          style={{ color: accentColor }}
        >
          <User /> My Account
        </h1>
        <p className="text-sm text-gray-600">
          Manage your personal and contact details.
        </p>
      </header>

      <div className="p-6 rounded-lg border bg-white shadow-sm dark:bg-slate-900 dark:border-slate-800 max-w-md">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium">Full Name</label>
            <input
              type="text"
              defaultValue={patient.name}
              className="w-full border rounded-md p-2 mt-1"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">Email</label>
            <input
              type="email"
              defaultValue={patient.email}
              className="w-full border rounded-md p-2 mt-1"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">Phone</label>
            <input
              type="tel"
              defaultValue={patient.phone}
              className="w-full border rounded-md p-2 mt-1"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">Date of Birth</label>
            <input
              type="date"
              defaultValue={patient.dob}
              className="w-full border rounded-md p-2 mt-1"
            />
          </div>

          <button
            className="w-full mt-4 py-2 rounded-md text-white"
            style={{ backgroundColor: accentColor }}
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default Account;
