export const MockDiagnosisData = [
  {
    id: 1,
    patientName: "Karthik Raj",
    age: 32,
    gender: "Male",
    vitals: {
      heartRate: 78,
      oxygen: 98,
      temperature: 98.6,
      bloodPressure: "120/80",
      weight: 72,
    },
    appointments: [
      {
        id: 101,
        doctor: "Dr. Priya Sharma",
        specialization: "Cardiology",
        date: "2025-11-02",
        time: "10:30 AM",
        location: "CityCare Hospital, Room 204",
        status: "Confirmed",
      },
    ],
    labReports: [
      {
        id: 201,
        testName: "Blood Test",
        date: "2025-10-25",
        result: "Normal",
        notes: "All parameters within normal range.",
      },
    ],
    diagnosisHistory: [
      {
        id: 301,
        condition: "Hypertension",
        dateDiagnosed: "2023-09-18",
        status: "Under Control",
        prescribedMeds: ["Amlodipine 5mg", "Losartan 25mg"],
      },
    ],
  },
];

// 👇 ADD THIS LINE AT THE END
export default MockDiagnosisData;
